<header id="header" class="fixed-top d-flex align-items-center header-transparent">
    <div class="container d-flex justify-content-between align-items-center">

      <div class="logo">
        <!-- <h1 class="text-light"><a href="index.html"><span>Moderna</span></a></h1> -->
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="/"><img src="{{asset('assets/img/leaditicon.png')}}" alt="" class="img-fluid"></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="active " href="/">হোম</a></li>
          <li><a href="about.html">আমোদের সম্পর্কে</a></li>
          <li><a href="services.html">যোগাযোগ</a></li>
          <li class="dropdown"><a href="#"><span>কোর্স
          </span> <i class="bi bi-chevron-down"></i></a>
            <ul>

              <li><a href="#">গ্রোফিক্স ডিজাইন
              </a></li>
              <!-- <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                </ul>
              </li> -->
              <li><a href="#">ওয়েব ডেভেলপমেন্ট</a></li>
              <li><a href="#">অ্যাপ ডেভেলপমেন্ট</a></li>
              <li><a href="#">ডিজিটাল মার্কেটিং
              </a></li>
            </ul>
          </li>
          <li><a href="contact.html">স্কলারশিপ</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
        <!-- <img class="bi bi-list mobile-nav-toggle" src="{{asset('assets/img/dropicon.png')}}" alt="" srcset=""> -->
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
