@extends('layouts.master')

@section('content')





  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-cntent-center align-items-center" >

    <div id="heroCarousel" class="container carousel carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

      <!-- Slide 1 -->
      @foreach($courses as $key =>$course)
      <div @if($key == 0) class="carousel-item active" @else class="carousel-item" @endif>
        <div class="carousel-container">
          <h2 class="animate__animated animate__fadeInDown">{{$course->title}}</h2>
          <p class="animate__animated animate__fadeInUp">{{$course->description}}</p>
          <a href="" class="btn-get-started animate__animated animate__fadeInUp">Read More</a>
        </div>
      </div>
      @endforeach

  

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">


  <section style="text-align:center;background-image:url('assets/img/itback.png');background-size: auto;" class="services section-bg">
      <div class="container">
        <h1>লিড আইটি ইন্সিটিউট</h1>
        <hr>
        <blockquote style="font-weight:bold;padding:20px;">
          বর্তমানে বাংলাদেশে যে বিষয়টি নিয়ে সব থেকে বেশি আলোচনা হচ্ছে সেটি হল ফ্রিল্যান্সিং। বাংলাদেশের ফ্রিল্যান্স আউটসোর্সিং ক্ষেত্রটি যে 
          এগিয়ে যাচ্ছে সেটি নতুন করে বলার কিছু নেই, তবে এ ক্ষেত্রকে দ্রুত এগিয়ে নিতে সচেতনতা তৈরি করাটা অনেক গুরুত্বপূর্ণ। আমাদের দেশে এখন লক্ষ 
          লক্ষ বেকার চাকুরির আশায় ঘুরছে, কর্মের সুযোগ খুঁজে ফিরছে। এই বিপুল জনসাধারণকে কাজ দিতে না পারলে এই কর্মক্ষম লোকগুলো আমাদের জন্য সম্ভাবনা 
          না হয়ে বরং বোঝা হবে। শুধু বিদেশে লোক পাঠিয়ে বা গার্মেন্টস ইন্ডাস্ট্রির মাধ্যমে এত কাজ দেয়া সম্ভব না। বাংলাদেশের এই শিক্ষিত বিপুল কর্মক্ষম
           জনগনের কাজের জন্য অনলাইন আউটসোর্সিং শিল্পের অনলাইন ফ্রিল্যান্স পেশাদার হিসাবে গড়ে তোলা অন্যতম ফলপ্রসু  একটি সমাধান হতে পারে।প্রযুক্তির অগ্রযাত্রার এই সময়ে বলা হচ্ছে, 
           আগামীতে আয়ের বড় উৎস এবং কর্মসংস্থানের একটি বৃহৎ সেক্টর হবে ফ্রিল্যান্সিং। ফ্রিল্যান্সার হওয়ার স্বপ্নটা সবার মধ্যেই রয়েছে। প্রত্যেকেই চায় পড়ালেখা কিংবা চাকুরির পাশাপাশি ঘরে বসেই ভাল পরিমাণ কিছু আয় করতে। আর এই সুযোগে রাতারাতি বড়লোক হবার বাহারি ও রকমারি বিজ্ঞাপনের মাধ্যমে মানুষকে আকৃষ্ট করার পায়তারায় মত্ত  হয়ে আছে একটি শ্রেণী। অনলাইনে আয় করার এইসব বাহারি বিজ্ঞাপনে আকৃষ্ট হয়ে প্রতারিতও হচ্ছেন অনেকে। অনেকে আউটসোর্সিং ও অনলাইনে আয় বিষয় দুটোকে একসঙ্গে গুলিয়ে ফেলছেন।এর প্রধান কারন হল ফ্রীলাঞ্চিং সম্পর্কে স্পষ্ট ধারণার অভাব।ফ্রিল্যান্সিং শুরু করতে গেলে একটা জিনিস অবশ্যই মাথায় রাখতে হবে &#8211; প্রশিক্ষণ শুধু একজন মানুষকে রাস্তা দেখাবে, কিন্তু তারপর পথ চলতে হবে নিজেকেই। এই পথ চলতে চলতেই নিজেকে আরো নিপুন ভাবে তৈরী হতে হবে, কর্মদক্ষ হতে হবে।</p>
        </blockquote>

      </div>
    </section><!-- End Services Section -->

 
  <section class="portfolio">
      <div class="container">
        <div id="portfolio-flters">
          <h1>আমাদের কোর্সসমুহ</h1>
          <hr>
        </div>
       

        <div class="row portfolio-container" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">
@foreach($courses as $course)
          
          <div class="col-lg-4 col-md-6 portfolio-wrap filter-app">
          <a href="{{route('course_details',$course->id)}}">
            <div style="text-align:center" class="portfolio-item">
            <h3 style="color:#ffffff;padding:10px">{{$course->title}}</h3>
              <img src="{{'storage'.$course->thumbnil}}" class="img-fluid" alt="">
              <div class="portfolio-info">
                
                <div style="padding:20px">
                  <p>{{$course->description}}</p>
                </div>
              </div>
            </div>
            </a>
          </div>
     
@endforeach

        </div>

      </div>
    </section>

    <section class="services section-bg">
      <div class="container section-bg" >

        <div class="row" style=" display: flex;align-items: center;">


          <div class="col-md-2 col-lg-2" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <b>  Partner </b> 
            </div>
          </div>

          <div class="col-md-2 col-lg-2" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <b>  Partner </b>  
            </div>
          </div>

          <div class="col-md-2 col-lg-2" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <b>  Partner </b> 
            </div>
          </div>

          <div class="col-md-2 col-lg-2" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <b>  Partner </b>  
            </div>
          </div>

          <div class="col-md-2 col-lg-2" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <b>  Partner </b>
            </div>
          </div>

          <div class="col-md-2 col-lg-2" data-aos="fade-up">
            <div class="icon-box icon-box-pink">
              <b>  Partner </b> 
            </div>
          </div>


        </div>

      </div>
    </section>

    <section class="map mt-2">
      <div class="container-fluid p-0">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a23e28c1191%3A0x49f75d3281df052a!2s150%20Park%20Row%2C%20New%20York%2C%20NY%2010007%2C%20USA!5e0!3m2!1sen!2sbg!4v1579767901424!5m2!1sen!2sbg" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
      </div>
    </section>

  </main><!-- End #main -->

  @endsection